import React from 'react';
import { useLocation } from 'react-router-dom';
import { Search, Bell } from 'lucide-react';

// Map routes to page titles
const routeTitles = {
  '/admin-dashboard': 'Dashboard',
  '/vendors': 'Vendors',
  '/bulk-upload': 'My Products',
  '/add-product': 'My Products',
  '/admin-inbox': 'Inbox',
  '/inventory': 'Inventory',
  '/qa-review': 'QA Review',
};

const Header = () => {
  const location = useLocation();

  let pageTitle = routeTitles[location.pathname];
  if (!pageTitle) {
    if (location.pathname.startsWith('/edit-product')) {
      pageTitle = 'My Products';
    } else {
      pageTitle = 'Page';
    }
  }

  return (
    <header className="flex items-center justify-between px-4 lg:px-8 py-3 lg:py-4 bg-white border-b border-gray-200 flex-shrink-0 w-full">
      {/* Page Title - in line with search bar and right side */}
      <div className="flex items-center gap-4 flex-1 min-w-0">
        <span className="font-bold text-lg lg:text-2xl text-gray-800 whitespace-nowrap">{pageTitle}</span>
        {/* Search Bar */}
        <div className="ml-20 relative flex-1 max-w-xs lg:max-w-md">
          <Search className="absolute left-2 lg:left-3 top-1/2 transform -translate-y-1/2 w-3 h-3 lg:w-4 lg:h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search product/order"
            className="w-full pl-8 lg:pl-10 pr-3 lg:pr-4 py-1.5 lg:py-2 bg-gray-100 rounded-lg border-0 focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
          />
        </div>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-2 lg:gap-4 ml-4">
        <button className="relative p-1 lg:p-2">
          <Bell className="w-4 h-4 lg:w-5 lg:h-5 text-gray-600" />
          <span className="absolute -top-0.5 -right-0.5 lg:-top-1 lg:-right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>
        <div className="flex items-center gap-2 lg:gap-3">
          <div className="w-6 h-6 lg:w-8 lg:h-8 bg-green-500 rounded-full flex items-center justify-center">
            <span className="text-white font-semibold text-xs lg:text-sm">AF</span>
          </div>
          <span className="font-medium text-gray-800 text-sm lg:text-base hidden sm:block">Andrew Forbit</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
